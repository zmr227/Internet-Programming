﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Storyphase.Models.ViewModels
{
    public class FavoriteViewModel
    {
        public List<Stories> Stories { get; set; }
    }
}
